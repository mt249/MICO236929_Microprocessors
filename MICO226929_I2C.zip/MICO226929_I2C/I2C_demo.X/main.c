#include "mcc_generated_files/mcc.h"
#include "lcd.h"
#include <stdio.h>

#define DS1307_Addr  0b01101000

void putch(char ch) {
    __delay_ms(1);
    LCDPutChar(ch);
}
//extern unsigned char LCD_PORT=0,Modified_LCD_PORT=0;



void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    LCD_Initialize();
    LCDPutCmd(LCD_CURSOR_BLINK);
  //  i2c_write1ByteRegister(DS1307_Addr,0x00,65);
        
    unsigned char temp=0;
    unsigned char str[10];  
        
    while (1)
    {

        temp = i2c_read1ByteRegister(DS1307_Addr,0x00);
        LCDPutCmd(LCD_HOME);
      //  Temp = 2;
        printf("second=%u",temp);
        
       // LCDPutChar(Temp);
       // sprintf("%d", temp);
        //printf("Hello=%u",temp);
        __delay_ms(1000);
        // Add your application code
    }
}
/**
 End of File
*/